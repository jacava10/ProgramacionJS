var texto = document.getElementById("t_lin");
var tecol = document.getElementById("t_col");
var boton = document.getElementById("botoncito");
boton.addEventListener("click", dibujoPorClick);

var d = document.getElementById("dibuDes1");
var lienzo = d.getContext("2d");

function dibujarLinea(color, x_ini, y_ini, x_fin, y_fin)
{
    lienzo.beginPath();
    lienzo.strokeStyle = color;
    lienzo.moveTo(x_ini, y_ini);
    lienzo.lineTo(x_fin, y_fin);
    lienzo.stroke();
    lienzo.closePath();
}

function dibujoPorClick()
{
var Colu = parseInt(texto.value);
var lineas = 30;
var l = 0;
var yi, xf;

/* dibujarLinea("blue", 0, 0, 10,300); 
 dibujarLinea("blue", 0, 0, 10,300); 
 dibujarLinea("blue", 0, 10, 20,300); 
 dibujarLinea("blue", 0, 20, 30,300);*/

/* while(l < lineas) */
for(l=0; l < lineas; l++)
{
    yi = 10 * l;
    xf = 10 * (l + 1);
    dibujarLinea("blue", 0, yi, xf, 300);
    dibujarLinea("red",300, yi, xf, 0); 
    dibujarLinea("green", 300, yi, 300-xf, 0);
    dibujarLinea("yellow",30, yi, 300-xf, 0);

    /* console.log("Linea " + l); */
    /* l++; por rl for */
}

dibujarLinea("#AFA",1, 1, 1, 299);
dibujarLinea("#AFA",1, 299, 299, 299);
}



function crea_tabla() {
   
    var body = document.getElementsByTagName("body")[0];
  
    var tabla   = document.createElement("table");
    var tblBody = document.createElement("tbody");

    var i_lin = texto.value;
    var i_col = tecol.value;
    // Faltaria validar que sean solo numeros en lineas y columnas
    // con un while hasta que las 2 variables, sean numeros
  
    for (var i = 0; i < i_lin; i++) {

      var hilera = document.createElement("tr");
  
      for (var j = 0; j < i_col; j++) {
  
        var celda = document.createElement("td");
        var i_h = i + 1;
        var i_c = j + 1;
        var textoCelda = document.createTextNode("Fila-" + i_h + ", Columna-" + i_c );
        celda.appendChild(textoCelda);
        hilera.appendChild(celda);
      }
  
      tblBody.appendChild(hilera);
    }
  
    tabla.appendChild(tblBody);
    body.appendChild(tabla);
    tabla.setAttribute("border", "6");
  }

